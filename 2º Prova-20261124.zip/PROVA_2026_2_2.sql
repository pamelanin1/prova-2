CREATE DATABASE prova2026_2_2;
use prova2026_2_2;

CREATE TABLE pessoa(
	pessoaID INT PRIMARY KEY AUTO_INCREMENT,
    cpf VARCHAR(20) NOT NULL UNIQUE,
    nomeCompleto VARCHAR(200) NOT NULL,
    email VARCHAR(200) UNIQUE NOT NULL,
    dataNascimento date,
    ct VARCHAR(200)
);

CREATE TABLE usuario(
	usuarioID INT PRIMARY KEY AUTO_INCREMENT,
    usuario VARCHAR(200) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    fk_pessoaID INT NOT NULL UNIQUE,
    FOREIGN KEY(fk_pessoaID) REFERENCES pessoa(pessoaID)
);

CREATE TABLE campeonato(
	campeonatoID INT PRIMARY KEY AUTO_INCREMENT,
    dataInicio DATE,
    dataFim DATE,
    nome VARCHAR(350),
    fk_usuarioID INT NOT NULL,
    FOREIGN KEY(fk_usuarioID) REFERENCES usuario(usuarioID)
);

CREATE TABLE categoria(
	categoriaID INT PRIMARY KEY AUTO_INCREMENT,
    nomeCategoria VARCHAR(200) NOT NULL,
    preRequisitos TEXT NOT NULL,
    qtdAtletas INT NOT NULL,
    fk_campeonatoID INT NOT NULL,
    FOREIGN KEY(fk_campeonatoID) REFERENCES campeonato(campeonatoID)
);

CREATE TABLE inscricao(
	inscricaoID INT PRIMARY KEY AUTO_INCREMENT,
    dataRealizacao DATE,
    valor decimal(10,2) DEFAULT 0,
    status VARCHAR(200),
    fk_categoriaID INT NOT NULL,
    FOREIGN KEY(fk_categoriaID) REFERENCES categoria(categoriaID)
);

CREATE TABLE prova(
	provaID INT PRIMARY KEY AUTO_INCREMENT,
    descricao TEXT NOT NULL,
    dataHora DATETIME,
    tipo VARCHAR(200),
    fk_categoriaID INT NOT NULL,
    FOREIGN KEY(fk_categoriaID) REFERENCES categoria(categoriaID)
);

CREATE TABLE resultado(
	resultadoID INT PRIMARY KEY AUTO_INCREMENT,
    pontuacao INT NOT NULL,
    posicao INT NOT NULL,
    marca VARCHAR(200),
    fk_provaID INT NOT NULL,
    fk_inscricaoID INT NOT NULL,
    FOREIGN KEY(fk_provaID) REFERENCES prova(provaID),
    FOREIGN KEY(fk_inscricaoID) REFERENCES inscricao(inscricaoID)
);

CREATE TABLE Inscricaiefetuada(
	InscricaiefetuadaID INT PRIMARY KEY AUTO_INCREMENT,
    NomeTime VARCHAR(250),
    fk_pessoaID INT NOT NULL,
    fk_inscricaoID INT NOT NULL,
    FOREIGN KEY(fk_pessoaID) REFERENCES pessoa(pessoaID),
    FOREIGN KEY(fk_inscricaoID) REFERENCES inscricao(inscricaoID)
);

