
SELECT * FROM inscricao INNER JOIN categoria ON categoriaID = fk_categoriaID;
-- QUestão 01
SELECT cat.nomeCategoria, c.nome, COUNT(*) 
	FROM categoria AS cat
    INNER JOIN campeonato AS c 
		ON c.campeonatoID = cat.fk_campeonatoID
	INNER JOIN inscricao AS i 
		ON i.fk_categoriaID = cat.categoriaID
	WHERE c.nome = 'Bope Games'
    GROUP BY cat.categoriaID HAVING count(inscricaoID) > 10;
    
SELECT cat.nomeCategoria,
	(SELECT COUNT(*) FROM inscricao 
		WHERE fk_categoriaID = cat.categoriaID) AS total
	FROM categoria AS cat
    INNER JOIN campeonato AS c 
		ON c.campeonatoID = cat.fK_campeonatoID
	WHERE (SELECT COUNT(*) FROM inscricao 
		WHERE fk_categoriaID = cat.categoriaID) > 10;
    
-- Questão 2
SELECT cat.nomeCategoria AS Categoria, c.nome AS Campeonato,
	cat.preRequisitos AS 'Pré-Requisitos', COUNT(*) AS 'Total de Provas'
    FROM prova AS p
    INNER JOIN categoria AS cat ON p.fk_categoriaID = cat.CategoriaID
    INNER JOIN campeonato AS c 
		ON c.campeonatoID = cat.fk_campeonatoID
    GROUP BY cat.CategoriaID;
    
SELECT cat.nomeCategoria AS Categoria, c.nome AS Campeonato,
	cat.preRequisitos AS 'Pré-Requisitos', 
    (SELECT COUNT(*) FROM prova WHERE fk_categoriaID = cat.CategoriaID)
    FROM categoria AS cat
    LEFT JOIN campeonato AS c 
		ON c.campeonatoID = cat.fk_campeonatoID;
    
-- Questão 3
SELECT nomeCompleto, cpf, email, usuario FROM pessoa
	LEFT JOIN usuario ON fk_pessoaID = pessoaID
    ORDER BY nomeCompleto DESC;
    
-- Questão 4
SELECT cat.NomeCategoria, i.inscricaoID, SUM(pontuacao) AS total FROM inscricao AS i
	INNER JOIN categoria AS cat ON cat.categoriaID = i.fk_categoriaID
    INNER JOIN campeonato AS c ON c.campeonatoID = cat.fK_campeonatoID
    INNER JOIN resultado AS r ON i.inscricaoID = r.fk_inscricaoID
    WHERE c.nome = 'Bope Games' AND cat.NomeCategoria = 'RX'
    GROUP BY i.inscricaoID ORDER BY total;
    
SELECT cat.NomeCategoria, i.inscricaoID, 
	(SELECT SUM(pontuacao) FROM resultado WHERE fk_inscricaoID = i.inscricaoID) AS total 
    FROM categoria AS cat
    INNER JOIN inscricao AS i ON i.fk_categoriaID = cat.categoriaID
    INNER JOIN campeonato AS c ON c.campeonatoID = cat.fK_campeonatoID
    WHERE c.nome = 'Bope Games' AND cat.NomeCategoria = 'RX';
    
    
-- QUESTÃO 5
SELECT c.nome, 
	(SELECT COUNT(*) FROM categoria WHERE fk_campeonatoID = c.campeonatoID) 
    FROM campeonato AS c;
    
SELECT c.nome, COUNT(*) FROM campeonato AS c
	INNER JOIN categoria AS cat 
		ON cat.fk_campeonatoID = c.campeonatoID
	GROUP BY campeonatoID HAVING COUNT(*);
    
-- Questão 6
SELECT i.valor, i.status, i.dataRealizacao, p.nomeCompleto, p.cpf, p.email
	FROM Inscricaiefetuada as e
    INNER JOIN inscricao AS i ON i.inscricaoID = e.fk_inscricaoID
    INNER JOIN pessoa AS p ON p.pessoaID = e.fk_pessoaID;


-- Questão 7
SELECT cat.nomeCategoria, cat.preRequisitos FROM categoria AS cat
	WHERE cat.categoriaID NOT IN (SELECT fK_categoriaID FROM prova);
    
SELECT cat.nomeCategoria, cat.preRequisitos FROM categoria AS cat
	LEFT JOIN prova AS p ON p.fk_categoriaID = categoriaID
    WHERE p.fk_categoriaID IS NULL;
    
-- questão 9
SELECT nome, dataInicio, dataFim FROM campeonato
	WHERE campeonatoID IN (SELECT fk_campeonatoID FROM categoria);
    
SELECT DISTINCT nome, dataInicio, dataFim FROM campeonato 
	INNER JOIN categoria ON fk_campeonatoID = campeonatoID;
    
-- questão 8
SELECT cat.nomeCategoria, c.nome, SUM(i.valor) FROM categoria AS cat
	INNER JOIN campeonato AS c ON c.campeonatoID = cat.fk_campeonatoID
    INNER JOIN inscricao AS i ON i.fk_categoriaID = cat.categoriaID
    WHERE status = 'efetivada'
    GROUP BY categoriaID;

-- Questão 10
SELECT p.nomeCompleto, p.cpf, p.email, 'Regional MT'
	FROM Inscricaiefetuada as e
    INNER JOIN inscricao AS i ON i.inscricaoID = e.fk_inscricaoID
    INNER JOIN pessoa AS p ON p.pessoaID = e.fk_pessoaID
    INNER JOIN categoria AS cat ON i.fk_categoriaID = cat.categoriaID
    WHERE fk_campeonatoID = 10
UNION
SELECT p.nomeCompleto, p.cpf, p.email, 'Arena Games'
	FROM Inscricaiefetuada as e
    INNER JOIN inscricao AS i ON i.inscricaoID = e.fk_inscricaoID
    INNER JOIN pessoa AS p ON p.pessoaID = e.fk_pessoaID
    INNER JOIN categoria AS cat ON i.fk_categoriaID = cat.categoriaID
    WHERE fk_campeonatoID = 5;
    

    